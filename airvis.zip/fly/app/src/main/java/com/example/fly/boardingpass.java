package com.example.fly;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class boardingpass extends AppCompatActivity {
    FirebaseFirestore db;
    ImageView back,download;

    TextView name, origin, destination, date, boardingtime, seat, cla, pnr,returndate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boardingpass);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        db = FirebaseFirestore.getInstance();
        pnr = findViewById(R.id.pnr);
        name = findViewById(R.id.name);
        origin = findViewById(R.id.o);
        download=findViewById(R.id.download);
        destination = findViewById(R.id.destination1);
        date = findViewById(R.id.date1);
        returndate = findViewById(R.id.returndate);
        cla = findViewById(R.id.class1);

        back = findViewById(R.id.back13);
        date = findViewById(R.id.date1);
        boardingtime = findViewById(R.id.boardingtime);
        seat = findViewById(R.id.seat);







        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(boardingpass.this, connect.class));
                finish();


            }
        });

        String pnr1 = getIntent().getStringExtra("pnr");
        String email = getIntent().getStringExtra("email");
        String seatadd = getIntent().getStringExtra("seat");
        CollectionReference collectionrefernce = db.collection("booking");


        collectionrefernce
                .whereEqualTo("pnr", pnr1)

                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                String pnr1 = getIntent().getStringExtra("pnr");
                                origin.setText(document.getString("origin"));

                                destination.setText(document.getString("destination"));

                                returndate.setText(document.getString("returndate"));

                                date.setText(document.getString("day"));

                                boardingtime.setText(document.getString("time"));

                                cla.setText(document.getString("class"));
                                pnr.setText(pnr1);


                            }
                        }
                    }


                });


        CollectionReference collectionrefernce1 = db.collection("registration");


        collectionrefernce1
                .whereEqualTo("emailormobileno", email)

                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {


                                name.setText(document.getString("name"));


                            }
                        }
                    }


                });



        CollectionReference collectionrefernce2 = db.collection("seat");


        collectionrefernce2

 .whereEqualTo("seat", seatadd)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {


                                seat.setText(document.getString("seat"));


                            }
                        }
                    }


                });


        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent;
                intent = new Intent(boardingpass.this, pdf.class);
                intent.putExtra("pnr", pnr.getText());
                intent.putExtra("seat", seat.getText());
                intent.putExtra("date", date.getText());
                intent.putExtra("origin", origin.getText());
                intent.putExtra("destination", destination.getText());
                intent.putExtra("time", boardingtime.getText());
                intent.putExtra("name", name.getText());
                intent.putExtra("returndate", returndate.getText());
                intent.putExtra("class", cla.getText());

                startActivity(intent);


            }
        });
    }

}



