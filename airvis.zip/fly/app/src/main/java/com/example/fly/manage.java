package com.example.fly;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class manage extends AppCompatActivity {
    Button cancel,modifydetails;
ImageView back;
      FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
back=findViewById(R.id.back6);
        cancel = findViewById(R.id.cancel);
        modifydetails = findViewById(R.id.modifydetails);
        db= FirebaseFirestore.getInstance();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(manage.this, connect.class));
                finish();


            }
        });




        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(manage.this);


                builder1.setMessage("Are you sure you want to cancel booking");

                builder1.setTitle("");


                builder1.setCancelable(false);

                builder1.setPositiveButton(
                        "Ok",
                        new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {


                                Intent intent;
                                intent = new Intent(manage.this,manage.class);

                                startActivity(intent);


                            }
                        });


                AlertDialog alertDialog1 = builder1.create();

                alertDialog1.show();
                String email= getIntent().getStringExtra("email");

                Map<String, Object> book = new HashMap<>();

                book.put("origin", "null");
                book.put("destination", "null");
                book.put("day", "null");
                book.put("time", "null");
                book.put("seat", "null");
                book.put("returndate","null");
                book.put("adult", "null");
                book.put("paymentconfirmation","refunded process started....");

                book.put("children", "null");
                book.put("infants", "null");
                book.put("class", "null");
                book.put("price", "null");
                book.put("pnr","null");

                db.collection("booking").document(email)
                        .set(book);

                AlertDialog.Builder builder = new AlertDialog.Builder(manage.this);


                builder.setMessage("Thanks for showing four interest.Your money will be transfer to your bank account within 6 hrs");

                builder.setTitle("");


                builder.setCancelable(false);

                builder.setPositiveButton(
                        "Ok",
                        new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                startActivity(new Intent(manage.this, manage.class));
                                finish();

                            }
                        });


                AlertDialog alertDialog = builder.create();

                alertDialog.show();




                            }
                        });




        modifydetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String email = getIntent().getStringExtra("email");
                Intent intent;
                intent = new Intent(manage.this, search.class);
                intent.putExtra("email", email);
                startActivity(intent);
            }
            });

    }
}
