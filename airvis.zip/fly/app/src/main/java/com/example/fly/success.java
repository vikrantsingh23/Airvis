package com.example.fly;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class success extends AppCompatActivity {

  ImageView forward;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        forward=findViewById(R.id.forward);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);









        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pnr = getIntent().getStringExtra("pnr");
                String emailsend = getIntent().getStringExtra("email");
                Intent email = new Intent(Intent.ACTION_SEND);
                email.putExtra(Intent.EXTRA_EMAIL, new String[]{ emailsend});

                email.putExtra(Intent.EXTRA_TEXT,pnr );

                //need this to prompts email client only
                email.setType("message/rfc822");

                startActivity(Intent.createChooser(email, "Choose an Email client :"));





    String children = getIntent().getStringExtra("children");
                                String adult = getIntent().getStringExtra("adult");

Intent intent;
                                intent = new Intent(success.this, checkin.class);
                                intent.putExtra("children", children);
                                intent.putExtra("adult", adult);

                                intent.putExtra("email", emailsend);
                                startActivity(intent);
                            }


                        });
            }




        }
