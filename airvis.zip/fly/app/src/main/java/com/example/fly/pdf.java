package com.example.fly;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


public class pdf extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf);
        webView=findViewById(R.id.webview);

        String pnr = getIntent().getStringExtra("pnr");

        String seat = getIntent().getStringExtra("seat");
        String name = getIntent().getStringExtra("name");
        String boardingtime = getIntent().getStringExtra("time");
        String returndate= getIntent().getStringExtra("returndate");
        String date = getIntent().getStringExtra("date");
        String origin = getIntent().getStringExtra("origin");
        String destination = getIntent().getStringExtra("destination");
        String class1 = getIntent().getStringExtra("class");




        String html="<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "\t<title></title>\n" +
                "\t<link rel=\"stylesheet\" type=\"text/css\" href=\"file:android_asset/pdfstyle.css\">\n" +
                "</head>\n" +
                "<body>\n" +
                "\t<div>\n" +
                "\t\t<h3>Boarding Pass</h3>\n" +
                "\t\t<table border=\"1\">\n" +
                "\t\t\t<tr>\n" +
                "\t\t\t\t<td>Name</td>\n" +
                "\t\t\t\t<td id=\"name\">"+name+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t\t<tr>\n" +
                "\t\t\t\t<td>Origin</td>\n" +
                "\t\t\t\t<td id=\"origin\">"+origin+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t\t<tr>\n" +
                "\t\t\t\t<td>Destination</td>\n" +
                "\t\t\t\t<td id=\"destination\">"+destination+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t\t<tr>\n" +
                "\t\t\t\t<td>Date</td>\n" +
                "\t\t\t\t<td id=\"Date\">"+date+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t</table>\n" +
                "\t\t\t\t<td>Returndate</td>\n" +
                "\t\t\t\t<td id=\"returnDate\">"+returndate+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t</table>\n" +
                "\t\t\t\t<td>Boarding Time</td>\n" +
                "\t\t\t\t<td id=\"boardingtime\">"+boardingtime+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t</table>\n" +

                "\t\t\t\t<td>Seat</td>\n" +
                "\t\t\t\t<td id=\"seat\">"+seat+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t</table>\n" +

                "\t\t\t\t<td>Class</td>\n" +
                "\t\t\t\t<td id=\"class\">"+class1+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t</table>\n" +

                "\t\t\t\t<td>Pnr</td>\n" +
                "\t\t\t\t<td id=\"pnr\">"+pnr+"</td>\n" +
                "\t\t\t</tr>\n" +
                "\t\t</table>\n" +
                "\t</div>\n" +
                "\n" +
                "</body>\n" +
                "</html>";
        webView.loadDataWithBaseURL(null,html,"text/html","utf-8",null);
    }





    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void CreatePdf(View view){
        Context context=pdf.this;
        PrintManager printManager=(PrintManager)pdf.this.getSystemService(PRINT_SERVICE);
        PrintDocumentAdapter adapter=null;
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){
            adapter=webView.createPrintDocumentAdapter();
        }
        String JobName=getString(R.string.app_name) +"Document";
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){
            PrintJob printJob=printManager.print(JobName,adapter,new PrintAttributes.Builder().build());
        }

    }
}

