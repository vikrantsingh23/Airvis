package com.example.fly;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;




public class menu extends AppCompatActivity {
    TextView origin, destination, date, time, price, origin1, destination1, date1, time1, price1,back1,back2;
    Button card1, card2;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        origin = findViewById(R.id.origin5);
        destination = findViewById(R.id.des5);
        date = findViewById(R.id.date5);
        time = findViewById(R.id.time5);
        price = findViewById(R.id.amount5);
        origin1 = findViewById(R.id.origin6);
        destination1 = findViewById(R.id.des6);
        date1 = findViewById(R.id.date6);
        time1 = findViewById(R.id.time6);
        price1 = findViewById(R.id.amount6);
        card1 = findViewById(R.id.book);
        card2 = findViewById(R.id.book1);
        back1 = findViewById(R.id.textView37);
        back2 = findViewById(R.id.textView39);
        db = FirebaseFirestore.getInstance();


        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(menu.this, search.class));
                finish();


            }
        });

        back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(menu.this, search.class));
                finish();


            }
        });





       String id= getIntent().getStringExtra("id");
String datetext = getIntent().getStringExtra("date");

if(datetext.equals("11/5/2020")) {

    CollectionReference collectionreference = db.collection("flight available");
    collectionreference
            .whereEqualTo("id", id)
            .get()
            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {

                            String datetext = getIntent().getStringExtra("date");
                            String diffclass = getIntent().getStringExtra("classs");
                        

                            origin.setText(document.getString("origin"));

                            destination.setText(document.getString("destination"));


                            origin1.setText(document.getString("origin"));
                            destination1.setText(document.getString("destination"));

                            time1.setText(document.getString("time1"));
                            time.setText(document.getString("time"));
                            date1.setText(datetext);
                            date.setText(datetext);

                            if (diffclass.equals("Economy class")) {

                                price.setText(document.getString("economyprice"));
                                price1.setText(document.getString("economyprice"));
                            }

                            if (diffclass.equals("Business class")) {

                                price.setText(document.getString("businessprice"));
                                price1.setText(document.getString("businessprice"));
                            }
                            if (diffclass.equals("First class")) {

                                price.setText(document.getString("firstclassprice"));
                                price1.setText(document.getString("firstclassprice"));
                            }


                        }


                    }
                }
            });


    card1.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String origin = getIntent().getStringExtra("origin");

                    String destination = getIntent().getStringExtra("destination");

                    String date = getIntent().getStringExtra("date");


                    String class1 = getIntent().getStringExtra("classs");



                    String children = getIntent().getStringExtra("children");

                    String adult = getIntent().getStringExtra("adult");

                    String infants = getIntent().getStringExtra("infants");

                    String email = getIntent().getStringExtra("email");
                    String member = getIntent().getStringExtra("member");

                    String price1 = price.getText().toString().trim();


                    String time1 = time.getText().toString().trim();



                    Intent intent = new Intent(menu.this, gpay.class);

                    intent.putExtra("amount", price1);
                    intent.putExtra("email", email);
                    intent.putExtra("members", member);
                    intent.putExtra("adult", adult);
                    intent.putExtra("children", children);
                    intent.putExtra("infants",infants);
                    intent.putExtra("time", time1);
                    intent.putExtra("origin", origin);


                    intent.putExtra("destination", destination);
                    intent.putExtra("class", class1);
                    intent.putExtra("date", date);

                    startActivity(intent);


                }
            });
    card2.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String origin = getIntent().getStringExtra("origin");

                    String destination = getIntent().getStringExtra("destination");

                    String date = getIntent().getStringExtra("date");


                    String class1 = getIntent().getStringExtra("classs");




                    String children = getIntent().getStringExtra("children");

                    String adult = getIntent().getStringExtra("adult");

                    String infants = getIntent().getStringExtra("infants");

                    String email = getIntent().getStringExtra("email");
                    String member = getIntent().getStringExtra("member");

                    String price2 = price1.getText().toString().trim();


                    String time2 = time1.getText().toString().trim();



                    Intent intent = new Intent(menu.this, gpay.class);

                    intent.putExtra("amount", price2);
                    intent.putExtra("email", email);
                    intent.putExtra("members", member);
                    intent.putExtra("adult", adult);
                    intent.putExtra("children", children);
                    intent.putExtra("infants",infants);
                    intent.putExtra("time", time2);
                    intent.putExtra("origin", origin);
                    intent.putExtra("destination", destination);
                    intent.putExtra("class", class1);
                    intent.putExtra("date", date);

                    startActivity(intent);


                }
            });


}
        if(datetext.equals("12/5/2020")) {

            CollectionReference collectionreference = db.collection("flight available");
            collectionreference
                    .whereEqualTo("id", id)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String datetext = getIntent().getStringExtra("date");
                                    String diffclass = getIntent().getStringExtra("classs");

                                    origin.setText(document.getString("origin"));

                                    destination.setText(document.getString("destination"));


                                    origin1.setText(document.getString("origin"));
                                    destination1.setText(document.getString("destination"));

                                    time1.setText(document.getString("time3"));
                                    time.setText(document.getString("time2"));
                                    date1.setText(datetext);
                                    date.setText(datetext);

                                    if (diffclass.equals("Economy class")) {

                                        price.setText(document.getString("economyprice"));
                                        price1.setText(document.getString("economyprice"));
                                    }

                                    if (diffclass.equals("Business class")) {

                                        price.setText(document.getString("businessprice"));
                                        price1.setText(document.getString("businessprice"));
                                    }
                                    if (diffclass.equals("First class")) {

                                        price.setText(document.getString("firstclassprice"));
                                        price1.setText(document.getString("firstclassprice"));
                                    }


                                }


                            }
                        }
                    });


            card1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin");

                            String destination = getIntent().getStringExtra("destination");

                            String date = getIntent().getStringExtra("date");


                            String class1 = getIntent().getStringExtra("classs");





                            String children = getIntent().getStringExtra("children");

                            String adult = getIntent().getStringExtra("adult");

                            String infants = getIntent().getStringExtra("infants");

                            String email1 = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member");

                            String price1 = price.getText().toString().trim();


                            String time1 = time.getText().toString().trim();

                            Intent intent = new Intent(menu.this, gpay.class);

                            intent.putExtra("amount", price1);
                            intent.putExtra("email", email1);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time1);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            intent.putExtra("returndate", "null");
                            startActivity(intent);


                        }
                    });
            card2.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin");

                            String destination = getIntent().getStringExtra("destination");

                            String date = getIntent().getStringExtra("date");


                            String class1 = getIntent().getStringExtra("classs");




                            String children = getIntent().getStringExtra("children");

                            String adult = getIntent().getStringExtra("adult");

                            String infants = getIntent().getStringExtra("infants");

                            String email2 = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member");

                            String price2 = price1.getText().toString().trim();


                            String time2 = time1.getText().toString().trim();




                            Intent intent = new Intent(menu.this, gpay.class);

                            intent.putExtra("amount", price2);
                            intent.putExtra("email", email2);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time2);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            intent.putExtra("returndate", "null");
                            startActivity(intent);


                        }
                    });


        }
        if(datetext.equals("13/5/2020")) {

            CollectionReference collectionreference = db.collection("flight available");
            collectionreference
                    .whereEqualTo("id", id)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String datetext = getIntent().getStringExtra("date");
                                    String diffclass = getIntent().getStringExtra("classs");

                                    origin.setText(document.getString("origin"));

                                    destination.setText(document.getString("destination"));


                                    origin1.setText(document.getString("origin"));

                                    destination1.setText(document.getString("destination"));

                                    time1.setText(document.getString("time5"));
                                    time.setText(document.getString("time4"));
                                    date1.setText(datetext);
                                    date.setText(datetext);

                                    if (diffclass.equals("Economy class")) {

                                        price.setText(document.getString("economyprice"));
                                        price1.setText(document.getString("economyprice"));
                                    }

                                    if (diffclass.equals("Business class")) {

                                        price.setText(document.getString("businessprice"));
                                        price1.setText(document.getString("businessprice"));
                                    }
                                    if (diffclass.equals("First class")) {

                                        price.setText(document.getString("firstclassprice"));
                                        price1.setText(document.getString("firstclassprice"));
                                    }


                                }


                            }
                        }
                    });


            card1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin");

                            String destination = getIntent().getStringExtra("destination");

                            String date = getIntent().getStringExtra("date");


                            String class1 = getIntent().getStringExtra("classs");



                            String children = getIntent().getStringExtra("children");

                            String adult = getIntent().getStringExtra("adult");

                            String infants = getIntent().getStringExtra("infants");

                            String email3 = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member");

                            String price1 = price.getText().toString().trim();


                            String time1 = time.getText().toString().trim();



                            Intent intent = new Intent(menu.this, gpay.class);

                            intent.putExtra("amount", price1);
                            intent.putExtra("email", email3);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time1);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            intent.putExtra("returndate", "null");
                            startActivity(intent);


                        }
                    });
            card2.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin");

                            String destination = getIntent().getStringExtra("destination");

                            String date = getIntent().getStringExtra("date");


                            String class1 = getIntent().getStringExtra("classs");




                            String children = getIntent().getStringExtra("children");

                            String adult = getIntent().getStringExtra("adult");

                            String infants = getIntent().getStringExtra("infants");

                            String email4 = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member");

                            String price2 = price1.getText().toString().trim();


                            String time2 = time1.getText().toString().trim();




                            Intent intent = new Intent(menu.this, gpay.class);

                            intent.putExtra("amount", price2);
                            intent.putExtra("email", email4);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time2);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            intent.putExtra("returndate", "null");
                            startActivity(intent);


                        }
                    });


        }
    }
}