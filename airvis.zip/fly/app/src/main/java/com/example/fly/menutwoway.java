package com.example.fly;

  import androidx.annotation.NonNull;
  import androidx.appcompat.app.AppCompatActivity;
  import android.content.Intent;
  import android.content.pm.ActivityInfo;
  import android.os.Bundle;
  import android.view.View;
  import android.widget.Button;
  import android.widget.TextView;

   import com.google.android.gms.tasks.OnCompleteListener;
   import com.google.android.gms.tasks.Task;
   import com.google.firebase.firestore.CollectionReference;
   import com.google.firebase.firestore.FirebaseFirestore;
   import com.google.firebase.firestore.QueryDocumentSnapshot;
   import com.google.firebase.firestore.QuerySnapshot;



public class menutwoway extends AppCompatActivity {
    TextView origin, destination, date, time, price, origin1, destination1, date1, time1, price1,returndate1,returndate2,back,back1;
    Button card1, card2;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menutwoway);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        origin = findViewById(R.id.origin5);
        destination = findViewById(R.id.des5);
        date = findViewById(R.id.date5);
        time = findViewById(R.id.time5);
        price = findViewById(R.id.amount5);
        origin1 = findViewById(R.id.origin6);
        destination1 = findViewById(R.id.des6);
        date1 = findViewById(R.id.date6);
        returndate2 = findViewById(R.id.returndate);
        returndate1 = findViewById(R.id.returndate1);
        time1 = findViewById(R.id.time6);
        price1 = findViewById(R.id.amount6);
        card1 = findViewById(R.id.book);
        card2 = findViewById(R.id.book1);
        back1 = findViewById(R.id.textView37);
        back = findViewById(R.id.textView39);
        db = FirebaseFirestore.getInstance();


        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(menutwoway.this, search.class));
                finish();


            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(menutwoway.this, search.class));
                finish();


            }
        });






        String id= getIntent().getStringExtra("id");
        String datetext = getIntent().getStringExtra("date11");

        if(datetext.equals("11/5/2020")) {

            CollectionReference collectionreference = db.collection("flight available");
            collectionreference
                    .whereEqualTo("id", id)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String datetext = getIntent().getStringExtra("date11");
                                    String diffclass = getIntent().getStringExtra("class11");
                                    String returndate = getIntent().getStringExtra("datereturn11");

                                    origin.setText(document.getString("origin"));

                                    destination.setText(document.getString("destination"));


                                    origin1.setText(document.getString("origin"));
                                    destination1.setText(document.getString("destination"));

                                    time1.setText(document.getString("time1"));
                                    time.setText(document.getString("time"));
                                    date1.setText(datetext);
                                    date.setText(datetext);
                                    returndate2.setText(returndate);

                                    returndate1.setText(returndate);

                                    if (diffclass.equals("Economy class")) {
                                       String priceint=document.getString("economyprice");
                                       int priceint1=Integer.parseInt(priceint);
                                           int priceint3=priceint1*2;
                                           String convert=String.valueOf(priceint3);
                                        price.setText(convert);
                                        price1.setText(convert);
                                    }

                                    if (diffclass.equals("Business class")) {
                                        String priceint=document.getString("businessprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);
                                        price.setText(convert);
                                        price1.setText(convert);

                                    }
                                    if (diffclass.equals("First class")) {
                                        String priceint=document.getString("firstclassprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);
                                        price.setText(convert);
                                        price1.setText(convert);

                                    }


                                }


                            }
                        }
                    });


            card1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin11");
                            String pnr = getIntent().getStringExtra("pnr");
                            String destination = getIntent().getStringExtra("destination11");

                            String date = getIntent().getStringExtra("date11");

                            String returndate = getIntent().getStringExtra("datereturn11");


                            String class1 = getIntent().getStringExtra("class11");



                            String children = getIntent().getStringExtra("children11");

                            String adult = getIntent().getStringExtra("adult11");

                            String infants = getIntent().getStringExtra("infants11");

                            String email = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member11");


                            String price1 = price.getText().toString().trim();


                            String time1 = time.getText().toString().trim();


                            Intent intent = new Intent(menutwoway.this, Gpay2.class);

                            intent.putExtra("amount", price1);
                            intent.putExtra("email", email);
                            intent.putExtra("pnr", pnr);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time1);
                            intent.putExtra("returndate", returndate);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            startActivity(intent);


                        }
                    });
            card2.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin11");

                            String destination = getIntent().getStringExtra("destination11");
                            String pnr = getIntent().getStringExtra("pnr");
                            String date = getIntent().getStringExtra("date11");

                            String returndate = getIntent().getStringExtra("datereturn11");
                            String class1 = getIntent().getStringExtra("class11");




                            String children = getIntent().getStringExtra("children11");

                            String adult = getIntent().getStringExtra("adult11");

                            String infants = getIntent().getStringExtra("infants11");

                            String email = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member11");

                            String price2 = price1.getText().toString().trim();


                            String time2 = time1.getText().toString().trim();


                            Intent intent = new Intent(menutwoway.this, Gpay2.class);

                            intent.putExtra("amount", price2);
                            intent.putExtra("email", email);
                            intent.putExtra("pnr",pnr);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time2);
                            intent.putExtra("returndate", returndate);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            startActivity(intent);


                        }
                    });


        }
        if(datetext.equals("12/5/2020")) {

            CollectionReference collectionreference = db.collection("flight available");
            collectionreference
                    .whereEqualTo("id", id)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String datetext = getIntent().getStringExtra("date11");
                                    String diffclass = getIntent().getStringExtra("class11");

                                    origin.setText(document.getString("origin11"));
                                    String returndate = getIntent().getStringExtra("datereturn11");
                                    destination.setText(document.getString("destination"));


                                    origin1.setText(document.getString("origin"));
                                    destination1.setText(document.getString("destination"));

                                    time1.setText(document.getString("time3"));
                                    time.setText(document.getString("time2"));
                                    date1.setText(datetext);
                                    date.setText(datetext);
                                    returndate2.setText(returndate);
                                    returndate1.setText(returndate);

                                    if (diffclass.equals("Economy class")) {
                                        String priceint=document.getString("Economyprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);
                                        price.setText(document.getString(convert));
                                        price1.setText(document.getString(convert));
                                    }

                                    if (diffclass.equals("Business class")) {
                                        String priceint=document.getString("businessprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);
                                        price.setText(document.getString(convert));
                                        price1.setText(document.getString(convert));
                                    }
                                    if (diffclass.equals("First class")) {
                                        String priceint=document.getString("firstclassprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);

                                        price.setText(document.getString(convert));
                                        price1.setText(document.getString(convert));
                                    }


                                }


                            }
                        }
                    });


            card1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin11");

                            String destination = getIntent().getStringExtra("destination11");
                            String pnr = getIntent().getStringExtra("pnr");
                            String date = getIntent().getStringExtra("date11");


                            String class1 = getIntent().getStringExtra("class11");
                            String returndate = getIntent().getStringExtra("datereturn11");



                            String children = getIntent().getStringExtra("children11");

                            String adult = getIntent().getStringExtra("adult11");

                            String infants = getIntent().getStringExtra("infants11");

                            String email = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member11");

                            String price1 = price.getText().toString().trim();


                            String time1 = time.getText().toString().trim();


                            Intent intent = new Intent(menutwoway.this, Gpay2.class);

                            intent.putExtra("amount", price1);
                            intent.putExtra("email", email);

                            intent.putExtra("pnr",pnr);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time1);
                            intent.putExtra("returndate", returndate);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            startActivity(intent);


                        }
                    });
            card2.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin11");

                            String destination = getIntent().getStringExtra("destination11");

                            String date = getIntent().getStringExtra("date11");

                            String returndate = getIntent().getStringExtra("datereturn11");

                            String class1 = getIntent().getStringExtra("class11");


                            String pnr = getIntent().getStringExtra("pnr");

                            String children = getIntent().getStringExtra("children11");

                            String adult = getIntent().getStringExtra("adult11");

                            String infants = getIntent().getStringExtra("infants11");

                            String email = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member11");

                            String price2 = price1.getText().toString().trim();


                            String time2 = time1.getText().toString().trim();

                            Intent intent = new Intent(menutwoway.this, Gpay2.class);

                            intent.putExtra("amount", price2);
                            intent.putExtra("email", email);
                            intent.putExtra("pnr",pnr);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time2);
                            intent.putExtra("returndate", returndate);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            startActivity(intent);


                        }
                    });


        }
        if(datetext.equals("13/5/2020")) {

            CollectionReference collectionreference = db.collection("flight available");
            collectionreference
                    .whereEqualTo("id", id)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String datetext = getIntent().getStringExtra("date11");
                                    String diffclass = getIntent().getStringExtra("class11");

                                    origin.setText(document.getString("origin"));

                                    destination.setText(document.getString("destination"));

                                    String returndate = getIntent().getStringExtra("datereturn11");
                                    origin1.setText(document.getString("origin"));
                                    destination1.setText(document.getString("destination"));

                                    time1.setText(document.getString("time5"));
                                    time.setText(document.getString("time4"));
                                    date1.setText(datetext);
                                    date.setText(datetext);
                                    returndate1.setText(returndate);
                                    returndate2.setText(returndate);

                                    if (diffclass.equals("Economy class")) {
                                        String priceint=document.getString("Economyprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);

                                        price.setText(document.getString(convert));
                                        price1.setText(document.getString(convert));
                                    }

                                    if (diffclass.equals("Business class")) {

                                        String priceint=document.getString("businessprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);

                                        price.setText(document.getString(convert));
                                        price1.setText(document.getString(convert));
                                    }
                                    if (diffclass.equals("First class")) {
                                        String priceint=document.getString("firstclassprice");
                                        int priceint1=Integer.parseInt(priceint);
                                        int priceint3=priceint1*2;
                                        String convert=String.valueOf(priceint3);

                                        price.setText(document.getString(convert));
                                        price1.setText(document.getString(convert));
                                    }


                                }


                            }
                        }
                    });


            card1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin11");

                            String destination = getIntent().getStringExtra("destination11");

                            String date = getIntent().getStringExtra("date11");

                            String returndate = getIntent().getStringExtra("datereturn11");
                            String class1 = getIntent().getStringExtra("class11");


                            String pnr = getIntent().getStringExtra("pnr");

                            String children = getIntent().getStringExtra("children11");

                            String adult = getIntent().getStringExtra("adult11");

                            String infants = getIntent().getStringExtra("infants11");

                            String email = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member11");

                            String price1 = price.getText().toString().trim();


                            String time1 = time.getText().toString().trim();



                            Intent intent = new Intent(menutwoway.this, Gpay2.class);

                            intent.putExtra("amount", price1);
                            intent.putExtra("email", email);
                            intent.putExtra("pnr",pnr);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time1);
                            intent.putExtra("returndate", returndate);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            startActivity(intent);


                        }
                    });
            card2.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            String origin = getIntent().getStringExtra("origin11");

                            String destination = getIntent().getStringExtra("destination11");
                            String pnr = getIntent().getStringExtra("pnr");
                            String date = getIntent().getStringExtra("date11");
                            String returndate = getIntent().getStringExtra("datereturn11");

                            String class1 = getIntent().getStringExtra("class11");


                            String children = getIntent().getStringExtra("children11");

                            String adult = getIntent().getStringExtra("adult11");

                            String infants = getIntent().getStringExtra("infants11");

                            String email = getIntent().getStringExtra("email");
                            String member = getIntent().getStringExtra("member11");

                            String price2 = price1.getText().toString().trim();


                            String time2 = time1.getText().toString().trim();



                            Intent intent = new Intent(menutwoway.this, Gpay2.class);

                            intent.putExtra("amount", price2);
                            intent.putExtra("email", email);
                            intent.putExtra("pnr",pnr);
                            intent.putExtra("members", member);
                            intent.putExtra("adult", adult);
                            intent.putExtra("children", children);
                            intent.putExtra("infants",infants);
                            intent.putExtra("time", time2);
                            intent.putExtra("returndate", returndate);
                            intent.putExtra("origin", origin);
                            intent.putExtra("destination", destination);
                            intent.putExtra("class", class1);
                            intent.putExtra("date", date);
                            startActivity(intent);


                        }
                    });


        }
    }
}