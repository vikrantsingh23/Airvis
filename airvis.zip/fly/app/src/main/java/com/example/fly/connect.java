package com.example.fly;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

public class connect extends AppCompatActivity {
FirebaseFirestore store;

ImageView back;
 Button  search,flight,contact,about,modify,account;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        search= findViewById(R.id.button3);
  store=FirebaseFirestore.getInstance();
        flight= findViewById(R.id.button4);
        contact= findViewById(R.id.button6);
        about= findViewById(R.id.button7);
        back=findViewById(R.id.imageView12);
        modify= findViewById(R.id.button5);
        account= findViewById(R.id.button8);



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(connect.this, login.class));
                finish();


            }
        });

            search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email1=  getIntent().getStringExtra("email");
                Intent intent;
                intent = new Intent(connect.this,search.class);
                intent.putExtra("email", email1);
                startActivity(intent);

            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String email2=  getIntent().getStringExtra("email");
                Intent intent;
                intent = new Intent(connect.this,contactus.class);
                intent.putExtra("email", email2);
                startActivity(intent);

            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(connect.this, aboutus.class));
                finish();

            }
        });
        flight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email3=  getIntent().getStringExtra("email");
                Intent intent;
                intent = new Intent(connect.this,flightstatus.class);
                intent.putExtra("email", email3);
                startActivity(intent);


            }
        });
        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email3=  getIntent().getStringExtra("email");
                Intent intent;
                intent = new Intent(connect.this,pnrmodify.class);
                intent.putExtra("email", email3);
                startActivity(intent);

            }
        });

        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=  getIntent().getStringExtra("email");
                String name=  getIntent().getStringExtra("name");
                Intent intent;
                intent = new Intent(connect.this,account.class);
                intent.putExtra("email", email);
                intent.putExtra("name", name);
                startActivity(intent);

            }
        });



    }
}
