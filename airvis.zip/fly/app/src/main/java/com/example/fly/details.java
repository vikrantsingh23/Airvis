package com.example.fly;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class details extends AppCompatActivity {
  FirebaseAuth auth;
    Button button;
    EditText address ,name;
    FirebaseFirestore store;

    ImageView back;


   RadioGroup gender;
     RadioButton radiogenderbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        store = FirebaseFirestore.getInstance();

     gender = findViewById(R.id.gender);
      address = findViewById(R.id.address);
        name = findViewById(R.id.fullname);
        button = findViewById(R.id.submit);
        back = findViewById(R.id.back);














        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(details.this, login.class));
                finish();


            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                    int selectedId = gender.getCheckedRadioButtonId();
                    radiogenderbutton = findViewById(selectedId);
                    String genders = radiogenderbutton.getText().toString().trim();

                    String nameput = name.getText().toString().trim();
                    String addressput = address.getText().toString().trim();

                String s=getIntent().getStringExtra("email");
                    Map<String, Object> book = new HashMap<>();
                    book.put("name", nameput);
                    book.put("address", addressput);

                    book.put("gender", genders);

                    store.collection("registration").document(s).
                            set(book);
                    Intent intent;
                    intent = new Intent(details.this, connect.class);

                    intent.putExtra("email", s);
                    intent.putExtra("name", nameput);

                    startActivity(intent);



            }
        });


            }

}