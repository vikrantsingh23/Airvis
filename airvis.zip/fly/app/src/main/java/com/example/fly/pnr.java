package com.example.fly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class pnr extends AppCompatActivity {
  EditText value;
  Button pnr;
  ImageView back;
  FirebaseFirestore store;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_pnr);
        pnr=findViewById(R.id.button2);
        back=findViewById(R.id.back14);
        value=findViewById(R.id.value);
    store=  FirebaseFirestore.getInstance();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                startActivity(new Intent(pnr.this, connect.class));
                finish();


            }
        });








        pnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pnr= value.getText().toString().trim();

            CollectionReference collectionrefernce = store.collection("booking");


            collectionrefernce
                    .whereEqualTo("pnr", pnr)

                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String pnr= value.getText().toString().trim();

                                            String email = getIntent().getStringExtra("email");
                                    String children = getIntent().getStringExtra("children");

                                    String adult = getIntent().getStringExtra("adult");


                                    Intent intent;
                                    intent = new Intent(pnr.this, checkin.class);
                                    intent.putExtra("pnr", pnr);
                                    intent.putExtra("children", children);
                                    intent.putExtra("adult", adult);

                                    intent.putExtra("email", email);

                                    startActivity(intent);


                                }
            }
             else{



                                AlertDialog.Builder builder= new AlertDialog.Builder(pnr.this);


                                builder.setMessage("Pnr not valid; please try again");

                                builder.setTitle("");


                                builder.setCancelable(false);

                                builder.setPositiveButton(
                                        "Ok",
                                        new DialogInterface
                                                .OnClickListener() {

                                            @Override
                                            public void onClick(DialogInterface dialog,
                                                                int which)
                                            {
                                                startActivity(new Intent(pnr.this, connect.class));
                                                finish();



                                            }
                                        });


                                AlertDialog alertDialog = builder.create();


                                alertDialog.show();




                            }


        }

                    });
            }
        });
    }
}
