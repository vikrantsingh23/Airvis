package com.example.fly;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class pnrmodify extends AppCompatActivity {
  EditText value;
  Button pnr;
  ImageView back;
  FirebaseFirestore store;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pnrmodify);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        pnr=findViewById(R.id.button2);
        back=findViewById(R.id.back14);
        value=findViewById(R.id.value);
    store=  FirebaseFirestore.getInstance();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                startActivity(new Intent(pnrmodify.this, connect.class));
                finish();


            }
        });








        pnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pnr= value.getText().toString().trim();
            CollectionReference collectionrefernce = store.collection("booking");


            collectionrefernce
                    .whereEqualTo("pnr", pnr)

                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    String pnr= value.getText().toString().trim();
                                    String email = getIntent().getStringExtra("email");


                                    Intent intent;
                                    intent = new Intent(pnrmodify.this, manage.class);
                                    intent.putExtra("pnr", pnr);
 intent.putExtra("email",email);
                                    startActivity(intent);


                                }
            }
             else{



                                AlertDialog.Builder builder= new AlertDialog.Builder(pnrmodify.this);

                                builder.setMessage("Pnr not valid; please try again");

                                builder.setTitle("");


                                builder.setCancelable(false);

                                builder.setPositiveButton(
                                        "Ok",
                                        new DialogInterface
                                                .OnClickListener() {

                                            @Override
                                            public void onClick(DialogInterface dialog,
                                                                int which)
                                            {
                                                startActivity(new Intent(pnrmodify.this, pnrmodify.class));
                                                finish();



                                            }
                                        });


                                AlertDialog alertDialog = builder.create();


                                alertDialog.show();




                            }


        }

                    });
            }
        });
    }
}
