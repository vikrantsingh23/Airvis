package com.example.fly;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;



public class checkin extends AppCompatActivity {
    FirebaseFirestore store;


  private static int count=0;

    ImageView one, two, three, four,back;
TextView totalseats,totalseats2,totalseats3,totalseats4,totalseats5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkin);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        store = FirebaseFirestore.getInstance();
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);

        totalseats2= findViewById(R.id.totalseats2);
        totalseats= findViewById(R.id.totalseats);
        totalseats3= findViewById(R.id.totalseats3);
        totalseats4= findViewById(R.id.totalseats4);
        totalseats5= findViewById(R.id.totalseats5);
        back = findViewById(R.id.back12);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);


        store = FirebaseFirestore.getInstance();
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(checkin.this, connect.class));
                finish();


            }
        });

        String children = getIntent().getStringExtra("children");
        int childrenint=Integer.parseInt(children);
        String adult = getIntent().getStringExtra("adult");

        int adultint=Integer.parseInt(adult);
        int totalmembers=childrenint+adultint;

    totalseats.setText("Select"+"    "+totalmembers+"     "+"Seats");
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (v.getId() == R.id.one ) {


                        AlertDialog.Builder builder = new AlertDialog.Builder(checkin.this);


                    builder.setMessage("confirm seat number 1-A");

                    builder.setTitle("");


                    builder.setCancelable(false);

                    builder.setPositiveButton(
                            "Ok",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    String children = getIntent().getStringExtra("children");
                                    int childrenint=Integer.parseInt(children);
                                    String adult = getIntent().getStringExtra("adult");

                                    int adultint=Integer.parseInt(adult);
                                    int totalmembers=childrenint+adultint;
                                    String pnr = getIntent().getStringExtra("pnr");

                                    String email = getIntent().getStringExtra("email");

                             if(count<totalmembers  ) {


                                 count++;

                           totalseats2.setText("1-A");




                             }

                                 if(count==totalmembers) {

                                     Map<String, Object> book = new HashMap<>();
                                     String seatadd=totalseats2.getText().toString().trim()+"  "+totalseats3.getText().toString().trim()+"  "+
                                             totalseats4.getText().toString().trim()+"  "+
                                             totalseats5.getText().toString().trim();
                                     book.put("seat", seatadd);
                                     store.collection("seat").document(email).
                                             set(book);
                                         Intent intent;
                                         intent = new Intent(checkin.this, boardingpass.class);
                                    intent.putExtra("pnr", pnr);
                                     intent.putExtra("seat", seatadd);
                                         intent.putExtra("email", email);
                                         startActivity(intent);
                                     }

                                }
                            });

                    builder.setCancelable(false);

                    builder.setNegativeButton(
                            "No",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    startActivity(new Intent(checkin.this, checkin.class));
                                    finish();

                                }
                            });


                    AlertDialog alertDialog = builder.create();

                    alertDialog.show();



                }
            }
        });


        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (v.getId() == R.id.two) {


                    AlertDialog.Builder builder = new AlertDialog.Builder(checkin.this);


                    builder.setMessage("confirm seat number 1-B");

                    builder.setTitle("");


                    builder.setCancelable(false);

                    builder.setPositiveButton(
                            "Ok",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    String children = getIntent().getStringExtra("children");
                                    int childrenint=Integer.parseInt(children);
                                    String adult = getIntent().getStringExtra("adult");

                                    int adultint=Integer.parseInt(adult);
                                    int totalmembers=childrenint+adultint;
                                    String pnr = getIntent().getStringExtra("pnr");

                                    String email = getIntent().getStringExtra("email");

                                    if (count < totalmembers) {


                                        count++;
                                        totalseats3.setText("1-B");


                                    }

                                     if(count==totalmembers)

                                {
                                    Map<String, Object> book = new HashMap<>();

                                    String seatadd=totalseats2.getText().toString().trim()+"  "+totalseats3.getText().toString().trim()+"  "+
                                            totalseats4.getText().toString().trim()+"  "+
                                            totalseats5.getText().toString().trim();
                                    book.put("seat", seatadd);
                                    store.collection("seat").document(email).
                                            set(book);
                                    Intent intent;
                                    intent = new Intent(checkin.this, boardingpass.class);
                                    intent.putExtra("pnr", pnr);
                                    intent.putExtra("seat", seatadd);
                                    intent.putExtra("seat1","1-B");
                                    intent.putExtra("email", email);
                                    startActivity(intent);
                                }


                            }
                            });

                    builder.setCancelable(false);

                    builder.setNegativeButton(
                            "No",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    startActivity(new Intent(checkin.this, checkin.class));
                                    finish();

                                }
                            });


                    AlertDialog alertDialog = builder.create();

                    alertDialog.show();


                }
            }
        });


        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (v.getId() == R.id.three) {


                    AlertDialog.Builder builder = new AlertDialog.Builder(checkin.this);


                    builder.setMessage("confirm seat number 2-A");

                    builder.setTitle("");


                    builder.setCancelable(false);

                    builder.setPositiveButton(
                            "Ok",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    String children = getIntent().getStringExtra("children");
                                    int childrenint=Integer.parseInt(children);
                                    String adult = getIntent().getStringExtra("adult");

                                    int adultint=Integer.parseInt(adult);
                                    int totalmembers=childrenint+adultint;
                                    String email = getIntent().getStringExtra("email");
                                    String pnr = getIntent().getStringExtra("pnr");

                                    if(count<totalmembers) {


                                        count++;


                                        totalseats4.setText("2-A");
                                    }

                                      if(count==totalmembers) {
                                          Map<String, Object> book = new HashMap<>();
                                          String seatadd=totalseats2.getText().toString().trim()+"  "+totalseats3.getText().toString().trim()+"  "+
                                                  totalseats4.getText().toString().trim()+"  "+
                                                  totalseats5.getText().toString().trim();
                                          book.put("seat", seatadd);
                                          store.collection("seat").document(email).
                                                  set(book);

                                        Intent intent;
                                        intent = new Intent(checkin.this, boardingpass.class);
                                          intent.putExtra("seat", seatadd);
                                        intent.putExtra("pnr", pnr);

                                        intent.putExtra("email", email);
                                        startActivity(intent);
                                    }





                                }
                            });


                    builder.setCancelable(false);

                    builder.setNegativeButton(
                            "No",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    startActivity(new Intent(checkin.this, checkin.class));
                                    finish();

                                }
                            });


                    AlertDialog alertDialog = builder.create();

                    alertDialog.show();


                }
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (v.getId() == R.id.four) {


                    AlertDialog.Builder builder = new AlertDialog.Builder(checkin.this);


                    builder.setMessage("confirm seat number 2-B");

                    builder.setTitle("");


                    builder.setCancelable(false);

                    builder.setPositiveButton(
                            "Ok",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    String children = getIntent().getStringExtra("children");
                                    int childrenint=Integer.parseInt(children);
                                    String adult = getIntent().getStringExtra("adult");

                                    int adultint=Integer.parseInt(adult);
                                    int totalmembers=childrenint+adultint;


                                    String email = getIntent().getStringExtra("email");
                                    String pnr = getIntent().getStringExtra("pnr");

                                    if(count<totalmembers) {


                                        count++;
                                        totalseats5.setText("2-B");

                                    }

                if(count==totalmembers) {
                    Map<String, Object> book = new HashMap<>();

                    String seatadd=totalseats2.getText().toString().trim()+"  "+totalseats3.getText().toString().trim()+"  "+
                            totalseats4.getText().toString().trim()+"  "+
                            totalseats5.getText().toString().trim();
                    book.put("seat", seatadd);
                    store.collection("seat").document(email).
                            set(book);
                                        Intent intent;
                                        intent = new Intent(checkin.this, boardingpass.class);
                                        intent.putExtra("pnr", pnr);
                    intent.putExtra("seat", seatadd);
                    intent.putExtra("seat3","2-B");
                                        intent.putExtra("email", email);
                                        startActivity(intent);
                                    }

                                }
                            });


                    builder.setCancelable(false);

                    builder.setNegativeButton(
                            "No",
                            new DialogInterface
                                    .OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    startActivity(new Intent(checkin.this, checkin.class));
                                    finish();

                                }
                            });


                    AlertDialog alertDialog = builder.create();

                    alertDialog.show();


                }
            }
        });
    }

}

